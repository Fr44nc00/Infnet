<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 11

### Utilize o arquivo _script.js_ para solucionar essa questão.

### Utilize __prompt__ e __alert__ para solucionar essa questão.

Construa um programa que determine, dada a categoria da carteira de motorista recebida em um `prompt`, quais veículos podem ser conduzidos.

* A - Motos e triciclos;
* B - Carros de passeio;
* C - Veículos de carga acima de 3,5 toneladas;
* D - Veículos com mais de 8 passageiros;
* E - Veículos com unidade acoplada acima de 6 toneladas.

**Utilize a estrutura de controle switch e retorne mensagens adequadas, inclusive se a entrada de dados não for válida.**

**Considere apenas uma categoria por vez (AB seria um escolha inválida).**