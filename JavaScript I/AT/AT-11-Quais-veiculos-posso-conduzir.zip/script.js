let carteira = prompt("Informe a categoria de sua carteira:").toLowerCase();

switch(carteira){
  case 'a':
    alert("Você pode conduzir motos e triciclos.");
    break
  case 'b':
    alert("Você pode conduzir carros de passeio.");
    break
  case 'c':
    alert("Você pode conduzir veículos de carga acima de 3,5 toneladas.");
    break
  case 'd':
    alert("Você pode conduzir veículos com mais de 8 passageiros.");
    break
  case 'e':
    alert("Você pode conduzir veículos com unidade acoplada acima de 6 toneladas.");
    break
  default:
    alert("Categoria inválida! Tente novamente.");
    break
}