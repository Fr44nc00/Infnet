let renda = prompt("Informe a renda mensal:");
let moradia = prompt("Informe o total de gastos com a moradia nesse mês:");
let edu = prompt("Informe o total de gastos com a educação nesse mês:");
let trans = prompt("Informe o total de gastos com o transporte nesse mês:");

let rendaM = renda * 0.3;
let rendaE = renda * 0.2;
let rendaT = renda * 0.15;

if(moradia < rendaM){
  if(edu < rendaE){
    if(trans < rendaT){
      alert("Você está dentro do orçamento!");
    }else{
      alert("O percentual de gasto com transporte deste mês é maior do que o aconselhado.")
    }
  }else{
    alert("O percentual de gasto com educação deste mês é maior do que o aconselhado.")
  }
}else{
  alert("O percentual de gasto com moradia deste mês é maior do que o aconselhado.")
}

let percentualM = (moradia / renda) * 100;
let percentualE = (edu / renda) * 100;
let percentualT = (trans / renda) * 100;

alert(`Os percentuais de gasto deste mês foram: ${percentualM}% com moradia, ${percentualE}% com educação e ${percentualT}% com transporte.`);