<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 10

Se possível, recomenda-se que as pessoas devem utilizar, no máximo, 30% da sua renda mensal à moradia, 20% à educação e 15% ao transporte. 

Esses valores são uma referência - não devem ser levados “ao pé da letra”.

Construa um programa que, dada a renda mensal, gastos com moradia, educação e transporte, faça um diagnóstico da situação. 

O programa deve informar se moradia, educação e transporte estão dentro do orçamento recomendado, e também qual é o percentual de renda utilizado em cada uma das categorias. 