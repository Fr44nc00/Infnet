<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 1

### Utilize o arquivo _script.js_ para solucionar essa questão.

### Utilize __prompt__ e __alert__ para solucionar essa questão.

Crie um programa que pergunte o nome do usuário, atribua a uma variável e exiba uma mensagem de saudação. 

Ex: "Bem Vindo, Machado de Assis".