let mensagem = prompt("Informe seu nome:");
alert("Seja bem vindo(a), " + mensagem + "!")