<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 4

### Utilize o arquivo _script.js_ para solucionar essa questão.

### Utilize __prompt__ e __alert__ para solucionar essa questão.

Um motorista deseja abastecer seu carro com um determinado valor em reais. 

Escreva um programa para ler o preço do litro do combustível e o valor que o motorista deseja abastecer. Por fim, mostre quantos litros foram colocados no tanque.

