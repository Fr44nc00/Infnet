let valorLitro = prompt("Insira o valor do combustível por litro (em reais):");

let valorMotorista = prompt("Agora insira o valor que o motorista pagará (em reais):");

let litrosColocados = valorMotorista / valorLitro;

alert(`${litrosColocados} litros de combustível foram colocados no tanque.`);