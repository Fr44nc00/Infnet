<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 13

### Utilize o arquivo _script.js_ para solucionar essa questão.

Criar uma função `getHoraMinutoSegundo` que retorna o tempo da data atual no seguinte formato: `hora:minuto:segundo`.