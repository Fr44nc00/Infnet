function getHoraMinutoSegundo(){
  let dataAtual = new Date();

  let h = dataAtual.getHours();
  let m = dataAtual.getMinutes();
  let s = dataAtual.getSeconds();

  return "O horário atual é " + h.toString() + ":" + m.toString() + ":" + s.toString() + ".";
}

alert(getHoraMinutoSegundo());