<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 9

Construa um programa que solicite do usuário três números através do `prompt` e informe qual deles é o maior e qual é o menor.