let num1 = prompt("Insira o primeiro número:");
let num2 = prompt("Insira o segundo número:");
let num3 = prompt("Insira o terceiro número:");

let maior = Math.max(num1, num2, num3);
let menor = Math.min(num1, num2, num3);

alert(`O maior número entre os informados é ${maior} e o menor número entre os informados é ${menor}.`)