<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 5

### Utilize o arquivo _script.js_ para solucionar essa questão.

### Utilize __prompt__ e __alert__ para solucionar essa questão.

Crie um programa que obtenha o valor de uma conta de restaurante. Assumindo que o valor da gorjeta seja de 10% em cima valor da conta, faça com que seu programa mostre o valor total a ser pago no restaurante (valor + gorgeta).
  