var conta = prompt("Informe o valor da conta (em reais):");

conta = conta * 1.1;

alert("O valor total da conta, incluindo a gorjeta, é de R$" + conta + ".")