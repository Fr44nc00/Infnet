<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 2

### Utilize o arquivo _script.js_ para solucionar essa questão.

Corrija o programa no arquivo `script,js`, de modo a eliminar os erros. Apenas substituia `let` por `const` e vice-versa.

**Caso uma variável não seja modificada no programa, o tipo de variável correta é const**
