// SUBSTITUA APENAS LET POR CONST E VICE-VERSA!
let a = 0;
const b = 5;
let c = 2;
const d = 1;
let e = 3;

a = 2;
c = 1;
e = 3;