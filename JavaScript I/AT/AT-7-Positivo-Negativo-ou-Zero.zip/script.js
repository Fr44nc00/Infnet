let num = prompt("Insira um número inteiro:");

if(num > 0){
  alert("O número é positivo.");
}else if(num == 0){
  alert("O número é zero.");
}else{
  alert("O número é negativo.");
}