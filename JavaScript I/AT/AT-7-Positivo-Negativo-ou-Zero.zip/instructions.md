<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 7

### Utilize o arquivo _script.js_ para solucionar essa questão.

### Utilize __prompt__ e __alert__ para solucionar essa questão.

Crie um programa que solicite ao usuário que digite um número inteiro. 

Informe se o número digitado é positivo, negativo ou zero.