// APENAS COMENTE ATÉ 3 LINHAS DE CÓDIGO PARA RESOLVER OS ERROS!

const a = 1;
// let b = 2;
const b = 2;
let c = 3;
// const c = 3;
let d = 4;

// a = 3;

d = a / b;
c = a / d;