<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 3

### Utilize o arquivo _script.js_ para solucionar essa questão.

Comente até 3 linhas de código para que o programa em `script.js` seja executado sem erros.