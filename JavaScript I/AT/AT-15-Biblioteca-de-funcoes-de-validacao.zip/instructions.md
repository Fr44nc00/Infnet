<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 15

Crie um arquivo __validacoes.js__ contendo as seguintes funções de validação:

* Função que verifica se o parâmetro está vazio (`null`, `undefined` ou sem comprimento);
* Função que verifica se o parâmetro possui um número mínimo de caracteres (receber esse dado como segundo parâmetro);
* Função que verifica se o parâmetro possui um número máximo de caracteres (receber esse dado como segundo parâmetro);
* Função que verifica se o parâmetro é um número inteiro;
* Função que verifica se o parâmetro é um número real.

Após a criação rode 2 testes para cada função criada no arquivo __validacoes.js__, exibindo o resultado no console do navegador.