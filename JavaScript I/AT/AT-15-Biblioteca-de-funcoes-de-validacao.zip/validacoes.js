function vazio(parametro){
  return parametro === null || parametro === undefined || parametro.length === 0;
}

console.log(vazio(''));
console.log(vazio('vazio'));

function minimo(parametro, minimo){
  return typeof parametro === 'string' && parametro.length >= minimo;
}

console.log(minimo('abcd', 3));
console.log(minimo('ab', 3));

function maximo(parametro, maximo){
  return typeof parametro === 'string' && parametro.length <= maximo;
}

console.log(maximo('abcd', 5));
console.log(maximo('abcdefghijklm', 5));

function inteiro(parametro){
  return Number.isInteger(parametro);
}

console.log(inteiro(5));
console.log(inteiro(5.1));

function real(parametro){
  return typeof parametro === 'number' && !Number.isNaN(parametro) && !Number.isInteger(parametro);
}

console.log(real(5.5));
console.log(real(5));