function getLocaleDate(){
  let idioma = navigator.language;
  let data = new Date();

  let dataAtual = data.toLocaleDateString(idioma);

  return dataAtual;
}

alert(getLocaleDate());