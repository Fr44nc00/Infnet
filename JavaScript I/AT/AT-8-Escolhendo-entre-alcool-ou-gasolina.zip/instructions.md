<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 8

### Utilize o arquivo _script.js_ para solucionar essa questão.

### Utilize __prompt__ e __alert__ para solucionar essa questão.

Um motorista deseja abastecer seu carro com um determinado valor em reais. 

Escreva um programa para ler o preço do litro do álcool e da gasolina e informe se o motorista deve usar um ou outro combustível.

O cálculo básico para descobrir se o álcool é vantajoso ou não em relação a gasolina é simples: basta dividir o preço do litro do álcool pelo da gasolina. 

Se o resultado for inferior a 0,7, use álcool; se for maior ou igual à 0,7, use gasolina.