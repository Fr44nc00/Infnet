let precoAl = prompt("Informe o preço do álcool por litro (em reais):");

let precoGas = prompt("Agora informe o preço da gasolina por litro (em reais):");

calculo = precoAl / precoGas;

let mensagem = (calculo < 0.7) ? "Abasteça seu carro com álcool." : "Abasteça seu carro com gasolina.";

alert(mensagem);