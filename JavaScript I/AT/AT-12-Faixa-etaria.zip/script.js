let faixaEtaria = prompt("Informe sua faixa etária:").toLowerCase();

switch(faixaEtaria){
  case "criança":
    alert("Sua idade varia entre alguns meses e 12 anos.");
    break;
  case "adolescente":
    alert("Sua idade varia entre 13 e 18 anos.");
    break;
  case "jovem":
    alert("Sua idade varia entre 19 e 35 anos.");
    break;
  case "adulto":
    alert("Sua idade varia entre 36 e 59 anos.");
    break;
  case "idoso":
    alert("Sua idade é de 60 anos ou mais.");
    break;
  default:
    alert("Categoria inválida. Insira uma das categorias válidas.");
}