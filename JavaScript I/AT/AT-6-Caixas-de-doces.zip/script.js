let quantDoces = prompt("Insira a quantidade de doces que foram fabricados:");

let capCaixa = prompt("Agora informe a capacidade total de cada caixa:");

let caixaCompleta = Math.ceil(quantDoces / capCaixa);

alert(`São necessárias ${caixaCompleta} caixas completas para comportar todos os doces.`);