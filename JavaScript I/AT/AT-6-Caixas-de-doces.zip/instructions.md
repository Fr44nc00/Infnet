<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Questão 6

Uma fábrica produz vários tipos de doces que são enviados para as lojas em caixas de vários tipos e tamanhos. 

Construa um programa que obtenha através de um `prompt` a **quantidade de doces fabricados** e a **capacidade da caixa**. Depois, mostre através de um `alert` quantas **caixas completas** serão necessárias para comportar todos os doces.

**OBS: "Caixas completas" é um número inteiro!**