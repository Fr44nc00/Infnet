function registrarDataRegistro() {
  return new Date().toLocaleString();
}

function registrarHistoricoAlteracao(aMensagem) {
  const ulHistoricoAlteracao = document.getElementById("historicoAlteracao");
  const liHistorico = document.createElement("li");
  liHistorico.textContent = aMensagem;
  ulHistoricoAlteracao.appendChild(liHistorico);
}

function registrarProduto(nome,tipo,tema,fornecedor,precoUnitario,descricao,quantidade) {
  return "Transação registrada! " + nome + ", Tipo do produto: " + tipo + ", Tema: " + tema + ", Fornecedor: " + fornecedor + ", Preço: R$" + precoUnitario + ", Detalhes: " + descricao + ", Quantidade em estoque: " + quantidade;
}

function registrar() {
  let nome = document.getElementById("nome").value;
  let tipo = document.getElementById("tipo").value;
  let tema = document.getElementById("tema").value;
  let fornecedor = document.getElementById("fornecedor").value;
  let precoUnitario = document.getElementById("preco").value;
  let descricao = document.getElementById("descricao").value;
  let quantidade = document.getElementById("quantidade").value;

  const mensagem = registrarProduto(nome,tipo,tema,fornecedor,precoUnitario,descricao,quantidade);

  registrarHistoricoAlteracao(mensagem);
}