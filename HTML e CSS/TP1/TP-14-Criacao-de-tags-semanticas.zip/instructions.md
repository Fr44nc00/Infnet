<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Teste de Performance 1

## Exercício 4

### _CONTEXTO:_

Você pode utilizar a tag `<header>` de diversas maneiras. No uso mais comum, apresenta informações introdutórias do início da página, como **cabeçalhos, imagens de logo ou contêiners**.

---

### _ENUNCIADO:_

Nesse exercício crie um `header`, que contenha os itens a seguir:

1. Cabeçalho escrito `Instituto Infnet`
2. O texto dentro dentro de uma tag `<p>`, deve vir assim:
    > O Instituto Infnet é a maior faculdade de tecnologia do Rio de Janeiro, com mais de 27 anos de história e mais de 20 mil alunos formados"

---

### _OBSERVAÇÕES:_

- **Coloque o title da página igual à `Instituto Infnet`**
- **Utilize a tag `<h1>` para o cabeçalho**
- **Os textos devem vir dentro da tag `<p>`**
- **Não esqueça de usar a tag `<header>`**