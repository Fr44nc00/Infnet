<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Teste de Performance 1

## Exercício 2

### _CONTEXTO:_

O primeiro exercício foi muito fácil!! Vamos fazer algo com um alcance um pouco maior??? Se no exercício anterior a gente disse `"Olá Mundo!"`, nesse exercício iremos escrever uma carta para ser acessada pelos futuros habitantes de Marte. Para tal, criaremos uma página Web, usando as tags `<p>` e `<br>`, que são usadas para criar parágrafos e quebras de linha.

---

### _ENUNCIADO:_

Essa carta precisa ter `3 parágrafos`:

1. No primeiro, você irá se apresentar.
2. No segundo, você irá escrever alguma coisa relevante sobre o planeta Terra.
3. No terceiro, pergunte como estão as coisas em Marte.
4. Quebre 2 linhas e escreva `"Saudações terráqueas"`
5. Por fim, quebre mais 1 linha e escreva seu nome.

---

### _OBSERVAÇÕES:_

- **Não se esqueça de usar `<p>` para os 3 parágrafos e `<br>` para as quebras de linha**

- **Os itens 4 e 5 não precisam estar escritos em uma tag `<p>`**