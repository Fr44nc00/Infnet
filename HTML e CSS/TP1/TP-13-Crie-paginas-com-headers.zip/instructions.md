<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Teste de Performance 1

## Exercício 3

### _CONTEXTO:_

Pronto! Agora você já se apresentou para todo mundo, dentro e fora do planeta Terra. Agora criaremos mais uma página.

---

### _ENUNCIADO:_

Nessa nova página, pedimos para você dissertar sobre `3 pontos`:

1. Explicar como funciona a Web e o que é uma página web
2. Explicar os papéis das linguagens HTML e CSS numa página web
3. Explicar o que são ambientes de programação?

---

### _OBSERVAÇÕES:_

- **Para cada um desses pontos, você irá criar uma tag `<h1>` com o título do item e a tag `<p>` com a explicação**

---

### _EXEMPLOS:_

> <h1> Como funciona a Web e o que é uma página web? </h1>
> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eu gravida urna. Aenean malesuada turpis nec interdum faucibus. Donec sollicitudin nisi eu enim tempus, sed accumsan elit condimentum. Duis quis fermentum nisl, at elementum ante. Cras ut varius metus, eget elementum eros. Mauris orci turpis, fermentum at lorem eget, consectetur faucibus dolor. Nulla auctor suscipit finibus. Aliquam ac vestibulum elit. Maecenas feugiat risus nec leo sollicitudin porta. Mauris vel magna vel ipsum tincidunt imperdiet. Donec sed egestas dui, eu elementum augue. </p>
