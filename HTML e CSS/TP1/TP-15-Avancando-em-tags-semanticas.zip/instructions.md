<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Teste de Performance 1

## Exercício 5

### _CONTEXTO:_

Você pode utilizar a tag `<article>` para definir o corpo de **artigos de blogs, fóruns e portais de notícias**

---

### _ENUNCIADO:_

Neste exercício, crie um `artigo` e dentro dele:

1. Crie um `header` que contenha:
    * Cabeçalho escrito `Instituto Infnet`
    * O texto dentro dentro da tag `<p>`, deve vir assim:
      > "O Instituto Infnet é a maior faculdade de tecnologia do Rio de Janeiro, com mais de 27 anos de história e mais de 20 mil alunos formados"

<br>

2. Um `parágrafo` que contenha o seguinte texto:
    > O Instituto Infnet é uma instituição privada de ensino superior sediada no Rio de Janeiro. Oferece cursos de graduação, pós-graduação e livres, presenciais e a distância. Seus cursos são voltados para as áreas de engenharia, computação, programação, ciência de dados, design, games, marketing digital, cinema, animação, publicidade e propaganda.

<br>   

3. Crie uma `quebra de texto` e em um `novo parágrafo`, escreva:

    > Fonte: Wikipedia

---

### _OBSERVAÇÕES:_

- **Coloque o title da página igual à `Instituto Infnet`**
- **Utilize a tag `<h1>` para o cabeçalho**
- **Utilize `<br>` para quebra de linha**
- **Os textos devem vir dentro da tag `<p>`**
- **Não esqueça de usar as tags `<header>` e `<article>`**