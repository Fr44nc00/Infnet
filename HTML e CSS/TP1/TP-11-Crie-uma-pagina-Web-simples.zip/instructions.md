<p align="center">
    <img src="https://www.infnet.edu.br/infnet/wp-content/themes/infnet.homepage//assets/img/LogoInfnetRodape.png"/>
</p>

# Teste de Performance 1

## Exercício 1

### _CONTEXTO:_

O primeiro exercício, é um clássico da computação! Todo mundo começa uma nova linguagem de programação aprendendo a dizer `"Olá Mundo!"`. Esse tipo de programa imprime "Olá, Mundo!" (ou "Hello, World!"), usualmente seguido de uma quebra de linha. É utilizado como um teste ou como um exemplo de código minimalista de uma linguagem de programação. Mas lembre-se: HTML não é uma linguagem de programação e sim de marcação!

---

### _ENUNCIADO:_

Então essa é a sua vez. Crie uma página que imprima na tela `"Olá Mundo!"`. Para tal, vá ao arquivo `index.html` e modifique o arquivo onde for necessário.

---

### _OBSERVAÇÕES:_

- **Não acrescente nenhuma tag nova!**